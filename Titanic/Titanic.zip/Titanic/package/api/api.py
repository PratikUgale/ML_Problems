from flask import Flask , jsonify , request
#import pandas as pd
from package.api.model import adv_prediction


app = Flask(__name__)

@app.route('/')
def home():
    return "welcome to RestAPI "

@app.route('/advance_prediction_house_price', methods=['POST'])

def predict():

    json_data = request.json
    print(json_data)
    obj = adv_prediction()

    result = obj.prediction(json_data)
    return jsonify({'House price with above given Parameter with nearest hundred $': list(result)})


if __name__ == '__main__':

    app.run(port=5000, debug=True)