import pandas as pd
from flask import Flask, jsonify, request
import os
from sklearn.externals import joblib


os.chdir(r"/Advance_Housing/datasets")
model = joblib.load('advance.pkl')

class adv_prediction():

    def __init__(self):

        print("Titanic object has created")


    def dataframe(self,data):

        data = pd.DataFrame(data)
        return data

    def create_new_col(self, data):
        '''In dataset, there is name of Passanger is mentioned but we dont require name of passanger
        we can catogerise person using its title name ,this method is used to split name and exctract only
        title of person e.g Mr, Mrs,Miss

        Also in dataset tjere are columns which gives information about passanger and which him how many persons has come
        with this we can create new feature call Family and add all family members in it'''

        data['Title'] = data['Name'].str.split(", ", expand=True)[1].str.split(".", expand=True)[0]
        data['Family'] = data['SibSp'] + data['Parch'] + 1
        return data

    def drop_col(self, data):
        '''Below listed columns are not necessary and didnt add any value important and not require for training datset
        so we are dropping it from dataset'''

        data.drop(['PassengerId', 'Name', 'SibSp', 'Parch', 'Ticket', 'Cabin', 'Fare'], axis=1, inplace=True)
        return data

    def dummy(self, data):
        '''This method is usefull for converting categorical feature into numerical form'''

        data = pd.get_dummies(data, drop_first=True).astype('float')
        return data

    def prediction(self,data):
        pass