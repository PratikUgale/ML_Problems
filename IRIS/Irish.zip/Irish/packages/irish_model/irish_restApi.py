from flask import Flask, jsonify
from packages.irish_model.irish_model import irish_model

app = Flask(__name__)

@app.route('/')
def home():
    return "welcome to RestAPI "

@app.route('/predict', methods=['POST'])

def predict():

    ''' This flask method is used to return the prediction done by model in Json to user , Here we are calling
        prediction method from irish_model classs'''
    obj = irish_model()
    result = obj.prediction()
    return jsonify({'Prediction result': list(result)})


if __name__ == '__main__':

    app.run(port=5000, debug=True)


