import sklearn
from sklearn.svm import SVC
import pandas as pd
from sklearn.externals import joblib
from flask import Flask, jsonify, request
import os
import numpy as np

# to change the directory of model file
os.chdir(r"F:\\Projects\\Irish\\packages\\irish_model")

# model pkl file
model_for_irish = joblib.load('save_model2.pkl')

class irish_model():

    def __init__(self):
        print("Model running object created")

    def prediction(self):

        '''This method is used for prediction , it collects the input in json format and
           convert it into pandas dataframe then dataframe passed to saved model which return the output of prediction'''
        json_data = request.json
        print(json_data)
        make_df = pd.DataFrame(json_data)
        print(make_df)

        prediction = model_for_irish.predict(make_df)
        print(prediction)

        return prediction
