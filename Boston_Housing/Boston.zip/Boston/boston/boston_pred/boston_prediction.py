import pandas as pd
import flask
import os
from sklearn.externals import joblib
from flask import Flask, jsonify, request

model_file = os.chdir('C:\Users\e5547887\Boston\data_model')

model = joblib.load('boston.pkl')


class boston_prediction():

    def __init__(self):

        print("boston prediction object has created")


    def prediction(self,data):

        #json_data = request.json
        #print(json_data)
        make_df = pd.DataFrame(data)
        print(make_df)

        prediction = model.predict(make_df)
        print(prediction)

        return prediction

#[
#	{'CRIM':0.00632, 'ZN':12.5, 'INDUS':7.07, 'CHAS':0.0, 'NOX':0.52, 'RM':7.1, 'AGE':61, 'DIS':5.6, 'RAD':7, 'TAX':400, 'PTRATIO':20, 'B':400, 'LSTAT':18}
#]