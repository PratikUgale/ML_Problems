from flask import Flask , jsonify , request
import pandas as pd
from boston.boston_pred import boston_prediction


app = Flask(__name__)

@app.route('/')
def home():
    return "welcome to RestAPI "

@app.route('/prediction_house_price', methods=['POST'])

def predict():

    json_data = request.json
    print(json_data)
    obj = boston_prediction()
    result = obj.prediction(json_data)
    return jsonify({'House price with above given Parameter with nearest hundred $': list(result)})


if __name__ == '__main__':

    app.run(port=5000, debug=True)