import pandas as pd
from flask import Flask, jsonify, request
import os
from sklearn.externals import joblib
from Scripts.Feature_engg.f_engineering import f_engg

os.chdir(r"/Advance_Housing/datasets")
model = joblib.load('advance.pkl')

class adv_prediction():

    def __init__(self):

        print("Sonar signal prediction object inititated")


    def prediction(self,data):

        make_df = pd.DataFrame(data)
        print(make_df)

        obj = f_engg()
        new_data = obj.drop_columns(make_df)
        dummy_data = obj.create_dummy(new_data)
        prediction = model.predict(dummy_data)
        print(prediction)

        return prediction