import pandas as pd
import numpy



class f_engg():

    def __init__(self):

        print("object for EDA is created")


    def drop_columns(self,data):
        '''it will drop the feutures which has missing value more than 50%'''
        data.drop(['Id','Alley','FireplaceQu','PoolQC','Fence','MiscFeature','GarageYrBlt'],axis=1,inplace=True)
        return data


    def create_dummy(self,data):

        data=pd.get_dummies(data,drop_first=True).astype('float')

        return data




