import pandas as pd
from flask import Flask, jsonify, request
import os
from sklearn.externals import joblib

os.chdir(r"C:\\Users\\e5547887\\Sonar\\dataset")
model = joblib.load('sonal.pkl')

class sonar_prediction():

    def __init__(self):

        print("Sonar signal prediction object inititated")


    def prediction(self,data):

        make_df = pd.DataFrame(data)
        print(make_df)

        prediction = model.predict(make_df)
        print(prediction)

        return prediction

