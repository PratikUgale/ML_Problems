from flask import Flask , jsonify , request
import pandas as pd
from sonar.api.sonar_prediction import  sonar_prediction


app = Flask(__name__)

@app.route('/')
def home():
    return "welcome to RestAPI "

@app.route('/prediction_house_price', methods=['POST'])

def predict():

    json_data = request.json
    print(json_data)
    obj = sonar_prediction()
    result = obj.prediction(json_data)
    return jsonify({'Return signal from sonar is from ': list(result)})


if __name__ == '__main__':

    app.run(port=5000, debug=True)